class AccountNotFound(Exception):
    pass


class InvalidPassword(Exception):
    pass
